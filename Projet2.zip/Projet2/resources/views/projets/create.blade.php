<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

<form>
  <div class="mb-3">
    <label for="code" class="form-label">Code</label>
    <input type="text" class="form-control" id="code">
  </div>
  <div class="mb-3">
    <label for="nom" class="form-label">Nom</label>
    <input type="text" class="form-control" id="nom">
  </div>
  <div class="mb-3">
    <label for="descript" class="form-label">Description</label>
    <input type="text" class="form-control" id="descript">
  </div>
  <div class="mb-3">
    <label for="budget" class="form-label">budget</label>
    <input type="number" class="form-control" id="budget">
  </div>
  <div class="mb-3">
    <label for="dateD" class="form-label">Date_debut</label>
    <input type="date" class="form-control" id="dateD">
  </div>
  <div class="mb-3">
    <label for="dateF" class="form-label">Date_fin</label>
    <input type="date" class="form-control" id="dateF">
  </div>
  <div class="mb-3">
    <label for="stat" class="form-label">Statut</label>
    <input type="text" class="form-control" id="stat">
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
    
</body>
</html>