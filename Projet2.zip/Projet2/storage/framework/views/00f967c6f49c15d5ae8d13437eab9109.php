<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <h2>Listes des projets</h2>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">code</th>
            <th scope="col">nom</th>
            <th scope="col">budget</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $nos_projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
          <tr>
            <th scope="row"><?php echo e($projet-> id); ?></th>
            <td colspan="2"><?php echo e($projet-> code); ?></td>
            <td><?php echo e($projet-> nom); ?></td>
            <td><?php echo e($projet-> budget); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
    

    

</body>
</html><?php /**PATH C:\Users\HP\Projet2\resources\views/projets/liste.blade.php ENDPATH**/ ?>