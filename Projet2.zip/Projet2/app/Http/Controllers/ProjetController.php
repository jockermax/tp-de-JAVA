<?php

namespace App\Http\Controllers;

use App\Models\Projet;
use Illuminate\Http\Request;

class ProjetController extends Controller
{
    
    public function index (){
        $liste_projets = Projet::all();
        return view("projets.liste", ["nos_projets" => $liste_projets]);
    }

    public function create ()
    {
        return view("projets.create");
    }
}
